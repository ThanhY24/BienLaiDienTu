<style>
    body{
        background-color: #323639;
    }
</style>
<iframe src="data:application/pdf;base64,{{ base64_encode($dataPDFReceipt) }}" width="100%" height="99%" style="border: none; margin: 0 auto;"></iframe>
