
<?php $__env->startSection('main_content'); ?>
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <h2 class="page-title">Thông tin người dùng</h2>
            </div>
        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <div class="col-12">
                <form
                    action="/user/update"
                    method="POST"
                    class="card"
                >
                    <?php echo csrf_field(); ?>
                    <div class="card-header">
                        <h4 class="card-title">Cập nhật thông tin người dùng</h4>
                    </div>
                    <div class="card-body">
                        <?php if(session('message')): ?>
                            <div class="alert alert-success" role="alert">
                                <h4 class="alert-title">Thông báo</h4>
                                <div class="text-secondary">Cập nhật thông tin người dùng thành công</div>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Họ và tên</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập họ và tên"
                                        name="name"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->name); ?>"
                                        <?php endif; ?>
                                    />
                                    
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Số điện thoại</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập số điện thoại"
                                        name="phone"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->phone); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Mã số thuế</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập mã số thuế"
                                        name="tax_id"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->tax_id); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Địa chỉ</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập địa chỉ"
                                        name="address"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->address); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Đường dẫn quản trị hóa đơn</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập đường dẫn quản trị hóa"
                                        name="link_services"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->link_services); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Đường dẫn tra cứu hóa đơn</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập đường dẫn tra cứu hóa đơn"
                                        name="link_lookup"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->link_lookup); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Tài khoản quản trị hóa đơn</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập tài khoản quản trị hóa đơn"
                                        name="username"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->username); ?>"
                                        <?php endif; ?>
                                        disabled
                                    />
                                </div>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Tài khoản services</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập tài khoản services"
                                        name="username_services"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->username_services); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Mật khẩu của tài khoản services</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập mật khẩu của tài khoản services"
                                        name="password_services"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->password_services); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Ký hiệu hóa đơn (Pattern)</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập ký hiệu hóa đơn"
                                        name="pattern"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->pattern); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Mẫu số hóa đơn (Serial)</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập mẫu số hóa đơn"
                                        name="serial"
                                        <?php if($dataUser): ?>
                                            value="<?php echo e($dataUser->serial); ?>"
                                        <?php endif; ?>
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-end">
                            <a href="#" type="submit" class="btn btn-success">
                                Quay Lại
                            </a>
                            <button type="submit" class="btn btn-danger">
                                Xác Nhận
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BienLaiDienTu\BienLaiDienTu\resources\views/pages/Users/UserDetailsPage.blade.php ENDPATH**/ ?>