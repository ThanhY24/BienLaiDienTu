
<?php $__env->startSection('main_content'); ?>
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <h2 class="page-title">Biên Lai</h2>
            </div>
        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <div class="col-12">
                <form
                    action="https://httpbin.org/post"
                    method="post"
                    class="card"
                >
                    <div class="card-header">
                        <h4 class="card-title">Thêm biên lai</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Text</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="example-text-input"
                                        placeholder="Input placeholder"
                                    />
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="mb-3">
                                    <label class="form-label">Text</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="example-text-input"
                                        placeholder="Input placeholder"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BienLaiDienTu\BienLaiDienTu\resources\views/pages/CreateReceiptPage.blade.php ENDPATH**/ ?>