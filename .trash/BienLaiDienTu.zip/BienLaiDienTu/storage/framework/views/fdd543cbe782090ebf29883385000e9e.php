 <?php $__env->startSection('main_content'); ?>
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <h2 class="page-title">Quản lý phí, lệ phí</h2>
            </div>
        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <?php if(session('message')): ?>
                <div class="alert alert-<?php echo e(session('type') == 'ERR' ? 'danger' : 'success'); ?>" role="alert">
                    <h4 class="alert-title"><?php echo e(session('type') == 'ERR' ? 'Cảnh báo' : 'Thông báo'); ?></h4>
                    <div class="text-secondary">
                        <?php echo e(session('message')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <div class="col-4">
                <form action="/fee" method="POST" class="card">
                    <?php echo csrf_field(); ?>
                    <div class="card-header">
                        <h4 class="card-title">Thêm phí, lệ phí mới</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 col-xl-12">
                                <div class="mb-3">
                                    <label class="form-label"
                                        >Mã phí, lệ phí</label
                                    >
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập không quá 20 ký tự"
                                        name="fee_id"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-xl-12">
                                <div class="mb-3">
                                    <label class="form-label"
                                        >Tên phí, lệ phí</label
                                    >
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập không quá 20 ký tự"
                                        name="fee_name"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-xl-12">
                                <div class="mb-3">
                                    <label class="form-label"
                                        >Đơn vị tính</label
                                    >
                                    <select class="form-select" name="fee_unit">
                                        <option value="VND">VND</option>
                                        <option value="USD">USD</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-xl-12">
                                <div class="mb-3">
                                    <label class="form-label"
                                        >Mức phí, lệ phí</label
                                    >
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Nhập không quá 20 ký tự"
                                        name="fee_cost"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-xl-12">
                                <div class="mb-3">
                                    <label class="form-label">Mô tả</label>
                                    <textarea
                                        class="form-control"
                                        name="fee_des"
                                        rows="3"
                                    ></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-end">
                            <button type="submit" class="btn btn-success">
                                Xác Nhận
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Danh sách phí, lệ phí mới</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-vcenter card-table">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Mã</th>
                                        <th>Tên</th>
                                        <th>Mức phí, lệ phí</th>
                                        <th>Đơn vị tính</th>
                                        <th class="w-1"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dataFee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-muted"><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($fee['fee_id']); ?></td>
                                        <td><?php echo e($fee['fee_name']); ?></td>
                                        <td><?php echo e(number_format($fee['fee_cost'])); ?></td>
                                        <td><?php echo e($fee['fee_unit']); ?></td>
                                        <td>
                                            <a href="#">Sửa</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BienLaiDienTu\BienLaiDienTu\resources\views/pages/Fee/FeePages.blade.php ENDPATH**/ ?>