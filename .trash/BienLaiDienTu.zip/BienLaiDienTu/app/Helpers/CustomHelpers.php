<?php
if (!function_exists('sendDateToVNPT')) {
    function sendDataToVNPT($servicesLink, $dataXML) {
        $client = new \GuzzleHttp\Client();;
        $response = $client->post($servicesLink, [
            'headers' => [
                'Content-Type' => 'application/soap+xml; charset=utf-8',
                'Content-Length' => strlen($dataXML),
            ],
            'body' => $dataXML,
        ]);
        $statusCode = $response->getStatusCode();
        $responseContent = $response->getBody()->getContents();
        if ($statusCode == 200) {
            return $responseContent;
        } else {
            return 500;
        }
    }
}
if (!function_exists('createFkey')) {
    function createFkey() {
        $now = now();
        $seconds = $now->second;
        $minutes = $now->minute;
        $hours = $now->hour;
        $day = $now->day;
        $month = $now->month;
        $year = $now->year;
        $randomNumber = mt_rand(100, 999);
        $fkey = "FKT$seconds$minutes$hours"."D$day$month$year"."RD$randomNumber";
        return $fkey;
    }
}
if (!function_exists('getDataFromResponseVNPT')) {
    function getDataFromResponseVNPT($responseVNPT, $xmlNode) {
        $xml = new DOMDocument();
        $xml->loadXML($responseVNPT);
        $ImportAndPublishInvResult = $xml->getElementsByTagName($xmlNode)->item(0);
        if($ImportAndPublishInvResult){
            $response = $ImportAndPublishInvResult->textContent;
            return $response;
        }else{
            return null;
        }
    }
}
if (!function_exists('XMLToArray')) {
    function XMLToArray($xmlString) {
        $xml = simplexml_load_string($xmlString);
        $json = json_encode($xml);
        $array = json_decode($json, true);
        return $array;
    }
}

if (!function_exists('getNoFromResponseVNPT')) {
    function getNoFromResponseVNPT($responseVNPT, $xmlNode) {
        $xml = new DOMDocument();
        $xml->loadXML($responseVNPT);
        $ImportAndPublishInvResult = $xml->getElementsByTagName($xmlNode)->item(0);
        $response = $ImportAndPublishInvResult->textContent;
        $parts = explode("_", $response);
        if (isset($parts[1])) {
            return $parts[1];
        }else{
            return null;
        }
    }
}
if (!function_exists('getNoFromResponseVNPTNew')) {
    function getNoFromResponseVNPTNew($responseVNPT, $xmlNode) {
        $xml = new DOMDocument();
        $xml->loadXML($responseVNPT);
        $ImportAndPublishInvResult = $xml->getElementsByTagName($xmlNode)->item(0);
        $response = $ImportAndPublishInvResult->textContent;
        $parts = explode(";", $response);
        if (isset($parts[2])) {
            return $parts[2];
        }else{
            return null;
        }
    }
}
if (!function_exists('getERRFromVNPT')) {
    function getERRFromVNPT($responseVNPT, $xmlNode) {
        $xml = new DOMDocument();
        $xml->loadXML($responseVNPT);
        $ImportAndPublishInvResult = $xml->getElementsByTagName($xmlNode)->item(0);
        $response = $ImportAndPublishInvResult->textContent;
        $parts = explode(":", $response);
        if (isset($parts[1])) {
            return $parts[1];
        }else{
            return null;
        }
    }
}
if (!function_exists('numberToWords')) {
    function numberToWords($number) {
        $ones = array(
            0 => 'Không',
            1 => 'Một',
            2 => 'Hai',
            3 => 'Ba',
            4 => 'Bốn',
            5 => 'Năm',
            6 => 'Sáu',
            7 => 'Bảy',
            8 => 'Tám',
            9 => 'Chín'
        );

        $suffixes = array(
            0 => '',
            1 => 'nghìn',
            2 => 'triệu',
            3 => 'tỷ'
        );

        if ($number == 0) {
            return $ones[0] . ' đồng';
        }

        $number = strval($number);
        $number = str_pad($number, ceil(strlen($number) / 3) * 3, '0', STR_PAD_LEFT);
        $parts = str_split($number, 3);
        $result = '';

        for ($i = 0; $i < count($parts); $i++) {
            $part = intval($parts[$i]);
            if ($part != 0) {
                $hundreds = floor($part / 100);
                $tens = floor(($part % 100) / 10);
                $onesDigit = $part % 10;
                if ($hundreds > 0) {
                    $result .= ucfirst($ones[$hundreds]) . ' trăm ';
                }
                if ($tens > 1) {
                    $result .= ucfirst($ones[$tens]) . ' mươi ';
                } elseif ($tens == 1) {
                    $result .= 'Mười ';
                }
                if ($onesDigit > 0 && $tens != 1) {
                    $result .= ucfirst($ones[$onesDigit]) . ' ';
                }
                $result .= $suffixes[count($parts) - 1 - $i] . ' ';
            }
        }
        return trim($result) . ' đồng';
    }
}

if (!function_exists('getToDay')) {
    function getToDay() {
        return now()->format('Y-m-d H:i:s');
    }
}
if (!function_exists('isBase64')) {
    function isBase64($data) {
        $decodedData = base64_decode($data, true);
        return ($decodedData !== false);
    }
}