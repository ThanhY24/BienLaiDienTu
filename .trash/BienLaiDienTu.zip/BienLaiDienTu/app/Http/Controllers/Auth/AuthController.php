<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
class AuthController extends Controller
{
    public function showLogin(){
        return view("login");
    }

    public function login(Request $request){
        $credentials = $request->only('username', 'password');

        if (Auth::attempt($credentials)) {
            return redirect('/home');
        }else{
            return redirect('/login')->with('message', 'Tên đăng nhập hoặc mật khẩu không đúng.');
        }
    }

    public function showRegister(){
        return view("register");
    }

    public function register(Request $request){
        $request->validate([
            'name' => 'required|string',
            'username' => 'required|string|unique:users',
            'password' => 'required|string|min:6',
        ]);
        User::create([
            'name' => $request->input('name'),
            'username' => $request->input('username'),
            'password' => Hash::make($request->input('password')),
            'password_admin' => $request->input('password'),
        ]);
        if(User::create([
            'name' => $request->input('name'),
            'username' => $request->input('username'),
            'password' => Hash::make($request->input('password')),
            'password_admin' => $request->input('password'),
        ])){
            return redirect('/login')->with('message', 'Đăng ký thành công!')->with('type', 'OK');
        }else{
            return redirect('/login')->with('message', 'Có lỗi khi đăng ký.')->with('type', 'ERR');
        }
    }
    
    public function logout(){
        Auth::logout();
        return redirect('/login');
    }
}
